import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;
public class Severity implements ActionListener{
	private JFrame f=new JFrame("Severity Page");
	private JLabel l=new JLabel("");
	private JLabel l1=new JLabel("Enter sid,did,fid,Severity to insert");
	private JLabel l2=new JLabel("Enter sid,did,fid to update");
	private JLabel l3=new JLabel("Enter sid to delete");
	private JLabel l4=new JLabel("Result");
	private JLabel l5=new JLabel("SEVERITY");
	private JButton b1=new JButton("Insert");
	private JButton b2=new JButton("Update");
	private JButton b3=new JButton("Delete");
	private JButton b4=new JButton("Retrieve");
	private JTextField t1=new JTextField();
	private JTextField t2=new JTextField();
	private JTextField t3=new JTextField();
	private JTextField t=new JTextField();
	private JTextArea t4=new JTextArea();
	private JScrollPane scrollBar=new JScrollPane(t4,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
	public Severity() {
		f.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		f.setBounds(100,150,1000,400); 
		Container c=f.getContentPane();
		f.getContentPane().add(l1);
		f.getContentPane().add(l2);
		f.getContentPane().add(l3);
		f.getContentPane().add(l4);
		f.getContentPane().add(l5);
		f.getContentPane().add(b1);
		f.getContentPane().add(b2);
		f.getContentPane().add(b3);
		f.getContentPane().add(b4);
		f.getContentPane().add(t1);
		f.getContentPane().add(t2);
		f.getContentPane().add(t3);
		f.getContentPane().add(t);
		f.getContentPane().add(scrollBar);
		scrollBar.setBounds(690,80,250,150);
		l.setBounds(20,30,50,50);
		l1.setBounds(60,80,250,30);
		l1.setOpaque(true);
		l1.setBackground(Color.WHITE);
		l2.setBounds(60,120,250,30);
		l2.setOpaque(true);
		l2.setBackground(Color.WHITE);
		l3.setBounds(60,160,250,30);
		l3.setOpaque(true);
		l3.setBackground(Color.WHITE);
		l4.setBounds(60,200,250,30);
		l4.setOpaque(true);
		l4.setBackground(Color.WHITE);
		l5.setBounds(430,5,700,50);	
        l5.setFont(new Font("Serif",Font.PLAIN,20));		
		l5.setForeground(Color.BLUE);
		b1.setBounds(570,80,100,30);
		b1.setFont(new Font("Times New Roman",Font.BOLD,17));
		b2.setBounds(570,120,100,30);
		b2.setFont(new Font("Times New Roman",Font.BOLD,17));
		b3.setBounds(570,160,100,30);
		b3.setFont(new Font("Times New Roman",Font.BOLD,17));
		b4.setBounds(570,200,100,30);
		b4.setFont(new Font("Times New Roman",Font.BOLD,17));
		t1.setBounds(330,80,220,30);
		t2.setBounds(330,120,220,30);
		t3.setBounds(330,160,220,30);
		t.setBounds(330,200,220,30);
		t4.setEditable(false);
		b1.addActionListener(this);
		b2.addActionListener(this);
		b3.addActionListener(this);
		b4.addActionListener(this);
		c.add(l);
		f.getContentPane().setBackground(Color.ORANGE);
		f.setVisible(true);
	}
	public void actionPerformed(ActionEvent ae){
		String s=new String(ae.getActionCommand());
		if((s).equals("Insert")){
			try{
				t.setText("1 row Inserted "+t1.getText());
				Class.forName("oracle.jdbc.OracleDriver");
				Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","lalitha","vasavi");
				Statement stmt=con.createStatement();
				StringTokenizer st=new StringTokenizer(t1.getText(),",");
				int sid=Integer.parseInt(st.nextToken());
				int did=Integer.parseInt(st.nextToken());
				int fid=Integer.parseInt(st.nextToken());
                String severity=st.nextToken();
				stmt.executeUpdate("insert into severity values("+sid+","+did+","+fid+",'"+severity+"')");
				con.close();
		}
		catch (Exception e) {
			t.setText("Error Occured!!");
		}
			t2.setText("");
			t3.setText("");
			t4.setText("");
		}
		else if((s).equals("Update")){
			try{
				t.setText("1 row Updated "+t2.getText());
				Class.forName("oracle.jdbc.OracleDriver");
				Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","lalitha","vasavi");
				Statement stmt=con.createStatement();
				StringTokenizer st=new StringTokenizer(t2.getText(),",");
				int sid=Integer.parseInt(st.nextToken());
				int did=Integer.parseInt(st.nextToken());
				int fid=Integer.parseInt(st.nextToken());
                String severity=st.nextToken();
				stmt.executeUpdate("Update severity set severity='"+severity+"' where sid="+sid+" and did="+did+" and fid="+fid+"");
				con.close();
			}
			catch(Exception e){
				t.setText("Error Occured!!");
			}
			t1.setText("");
			t3.setText("");
			t4.setText("");
		}
		else if((s).equals("Delete")){
			try{
				t.setText("Deleted 1 row with sid"+t3.getText());
				Class.forName("oracle.jdbc.OracleDriver");
				Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","lalitha","vasavi");
				Statement stmt=con.createStatement();
				int sid=Integer.parseInt(t3.getText());
				stmt.executeUpdate("delete from severity where sid="+sid+"");
			    con.close();
			}
			catch(Exception e){
				t.setText("Error Occured!!");
			}
			t1.setText("");
			t2.setText("");
			t4.setText("");
	    }
		else if((s).equals("Retrieve")){
			try{
				t.setText("Retrieved rows from Severity table");
				Class.forName("oracle.jdbc.OracleDriver");
				Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","lalitha","vasavi");
				Statement stmt=con.createStatement();
				ResultSet rs=stmt.executeQuery("select * from severity");
				String str=new String();
				while(rs.next())
				     str=str+(rs.getInt(1)+"  "+rs.getInt(2)+"  "+rs.getInt(3)+"  "+rs.getString(4)+"\n");
				t4.setText(str);
				con.close();
			}
			catch(Exception e){
				t.setText("Error Occured!!");
			}
			t1.setText("");
			t2.setText("");
			t3.setText("");
	    }		
	}
	public static void main(String[] args){
		new Severity();
	}
}

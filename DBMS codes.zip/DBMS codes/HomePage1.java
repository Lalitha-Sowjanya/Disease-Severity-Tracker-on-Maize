import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class HomePage1 extends JFrame{
	private JFrame frame= new JFrame(); 
	private JMenuBar mBar;
    private JMenu mnuHelp,insert,delete,update;
    private JMenuItem abt,defins,disins,facins,sevins,defdel,disdel,facdel,sevdel,defup,disup,facup,sevup;
	public HomePage1(){       
        frame.setTitle("Home Page");
        frame.setLayout(null); 
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
        frame.setBounds(100,150,600,350); 
		Container c=frame.getContentPane(); 
		initializeMenuBar();
        frame.setJMenuBar(mBar);
		abt.addActionListener(new HelpMenuActionListener());
		defins.addActionListener(new HelpMenuActionListener());
		disins.addActionListener(new HelpMenuActionListener());
		facins.addActionListener(new HelpMenuActionListener());
		sevins.addActionListener(new HelpMenuActionListener());
		defdel.addActionListener(new HelpMenuActionListener());
		disdel.addActionListener(new HelpMenuActionListener());
		facdel.addActionListener(new HelpMenuActionListener());
		sevdel.addActionListener(new HelpMenuActionListener());
		defup.addActionListener(new HelpMenuActionListener());
		disup.addActionListener(new HelpMenuActionListener());
		facup.addActionListener(new HelpMenuActionListener());
		sevup.addActionListener(new HelpMenuActionListener());
		JLabel label=new JLabel("DISEASE SEVERITY TRACKER ON MAIZE HOME PAGE");
		JLabel label1=new JLabel();
        label1.setIcon(new ImageIcon("C:/Users/sasid/Downloads/maize.jpg"));
        Dimension size = label1.getPreferredSize();
        label.setBounds(50,5,700,50);	
        label.setFont(new Font("Serif",Font.PLAIN,20));		
		label.setForeground(Color.BLUE);
		label1.setBounds(160,60, size.width,size.height);	
		c.add(label);
		c.add(label1);			
		frame.getContentPane().setBackground(Color.CYAN);		
		frame.setVisible(true); 
        }
		public void initializeMenuBar()
	    {
			mBar=new JMenuBar();
			mnuHelp=new JMenu("Help");
			insert=new JMenu("Insert");
			delete=new JMenu("Delete");
			update=new JMenu("Update");
			abt=new JMenuItem("About");
			defins=new JMenuItem("Deficiency");
			disins=new JMenuItem("Diseases");
			facins=new JMenuItem("Factors");
			sevins=new JMenuItem("Severity");
			defdel=new JMenuItem("Deficiency");
			disdel=new JMenuItem("Diseases");
			facdel=new JMenuItem("Factors");
			sevdel=new JMenuItem("Severity");
			defup=new JMenuItem("Deficiency");
			disup=new JMenuItem("Diseases");
			facup=new JMenuItem("Factors");
			sevup=new JMenuItem("Severity");
			mnuHelp.add(abt);
			insert.add(defins);
			insert.add(disins);
			insert.add(facins);
			insert.add(sevins);
			delete.add(defdel);
			delete.add(disdel);
			delete.add(facdel);
			delete.add(sevdel);
			update.add(defup);
			update.add(disup);
			update.add(facup);
			update.add(sevup);
			mBar.add(mnuHelp);
			mBar.add(insert);
			mBar.add(delete);
			mBar.add(update);
	    }	
		private class HelpMenuActionListener implements ActionListener {
			public void actionPerformed(ActionEvent ae) {
			if(ae.getSource()==abt)
			{
				String details;
				details = "This project is about tracking the severity of the disease on maize crop"+"\n"+
                          "It has 4 tables:"+"\n"+
                          "1.Deficiency table with rows containing deficiency Id as did,deficient element as elem and leaf colour as lcolor"+"\n"+
                          "2.Diseases table with rows containing disease Id as did,name of the disease as name and colour as scolor"+"\n"+
                          "3.Factors table with rows containing factor Id as fid and factor as factor"+"\n"+
                          "4.Severity table with rows containing severity Id as sid, deficiency Id as did,factor Id as fid and severity as severity";
				JOptionPane.showMessageDialog(null,details,"INFORMATION", JOptionPane.INFORMATION_MESSAGE);
			}
			else if(ae.getSource()==defins){
				new insertdeficiency();
			}
			else if(ae.getSource()==disins){
				new insertdiseases();
			}
			else if(ae.getSource()==facins){
				new insertfactors();
			}
			else if(ae.getSource()==sevins){
				new insertseverity();
			}
			else if(ae.getSource()==defdel){
				new deletedeficiency();
			}
			else if(ae.getSource()==disdel){
				new deletediseases();
			}
			else if(ae.getSource()==facdel){
				new deletefactors();
			}
			else if(ae.getSource()==sevdel){
				new deleteseverity();
			}
			else if(ae.getSource()==defup){
				new updatedeficiency();
			}
			else if(ae.getSource()==disup){
				new updatediseases();
			}
			else if(ae.getSource()==facup){
				new updatefactors();
			}
			else if(ae.getSource()==sevup){
				new updateseverity();
			}
		  }
		}	
	public static void main(String args[]){
		new HomePage1();
}
}

